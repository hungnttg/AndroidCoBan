package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    //B1 - Keó thả giao diện
    //B2 - Ánh xạ thành phần giao diện vào code java
    TextView tv1;//khai bao tv1
    Button btn1;//khai bao btn1
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv1 = findViewById(R.id.b1Tv1);//ánh xạ textview từ xml vào java
        btn1 = findViewById(R.id.b1Btn1);//ánh xạ button từ xml vào java


    }


    public void xlsk1(View view) {
        String ht_msv = "Nguyen Van An, ma sv la 123456";
        tv1.setText(ht_msv);

        Toast.makeText(getApplicationContext(),ht_msv,Toast.LENGTH_LONG).show();
    }
}
