package com.example.myapplication.bai4;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.example.myapplication.R;

import java.util.ArrayList;
import java.util.List;

public class Bai42Main2Activity extends AppCompatActivity {
    //Các bước tạo customlistview
    //1. Tạo layout itemview
    //2. Viết lớp Model
    //3. Viết Adapter
    //4. Tạo 1 listview và đưa dữ liệu vào adapter
    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bai42_main2);
        listView  =findViewById(R.id.listview1);
        List<Contact> arrContacts = new ArrayList<>();
        arrContacts.add(new Contact(Color.RED,"Nguyen Van a","0912345a"));
        arrContacts.add(new Contact(Color.GREEN,"Tran Van b","0912345b"));
        arrContacts.add(new Contact(Color.BLUE,"Vu Van C","0912345c"));
        arrContacts.add(new Contact(Color.DKGRAY,"Nguyen Thi D","0912345d"));
        arrContacts.add(new Contact(Color.RED,"Nguyen Van E","0912345e"));

        CustomAdapter adapter  =new CustomAdapter(this,R.layout.custom_listview,arrContacts);
        listView.setAdapter(adapter);
        //xu ly su kien
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Contact item = adapter.getItem(i);
                Toast.makeText(getApplicationContext(),
                        item.getName(),Toast.LENGTH_LONG).show();
            }
        });
    }
}
