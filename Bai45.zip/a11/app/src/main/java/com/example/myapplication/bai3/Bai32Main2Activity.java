package com.example.myapplication.bai3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.myapplication.R;

public class Bai32Main2Activity extends AppCompatActivity {
    EditText txt1,txt2,txt3;
    Button btn1;
    TextView tv1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bai32_main2);
        txt1 = findViewById(R.id.bai32Txt1);
        txt2 = findViewById(R.id.bai32Txt2);
        txt3 = findViewById(R.id.bai32Txt3);
        btn1  =findViewById(R.id.bai32Btn1);
        tv1 = findViewById(R.id.bai32Tv1);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                giai_pt();
            }
        });
    }

    private void giai_pt() {
        //Lay ve cac he so va chuyen sang kieu so nguyen
        String chuoiA = txt1.getText().toString();
        int a = Integer.parseInt(chuoiA);
        int b = Integer.parseInt(txt2.getText().toString());
        int c = Integer.parseInt(txt3.getText().toString());
        if(a==0)
        {
            tv1.setText("Ban phai nhap a!=0");
            return;
        }
        else
        {
            //tinh delta
            float delta = b*b-4*a*c;
            if(delta<0)
            {
                tv1.setText("PT Vo nghiem");
            }
            else if(delta==0)
            {
                float x1 = -b/(2*a);
                tv1.setText("PT co nghiem");
            }
            else
            {
                float x1 = (float) ((-b+Math.sqrt(delta))/(2*a));
                float x2 = (float) ((-b-Math.sqrt(delta))/(2*a));
                tv1.setText("PT co 2 nghiem x1 = "+x1+"; X2="+x2);
            }
        }

    }
}
