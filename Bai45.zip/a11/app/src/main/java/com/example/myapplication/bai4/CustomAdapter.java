package com.example.myapplication.bai4;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.myapplication.R;

import java.util.List;

public class CustomAdapter extends ArrayAdapter<Contact> {
    //2. Khai bao cac bien can khoi tao
    private Context context;
    private int resource;
    private List<Contact> objects;
    //3. Khai bao doi tuong ve giao dien
    private LayoutInflater inflater;
    public CustomAdapter(Context context, int resource, List<Contact> objects) {
        super(context, resource, objects);
        this.context = context;
        this.resource = resource;
        this.objects = objects;
        //khởi tạo đói tượng vẽ giao diện
        this.inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }
    //4. Tạo hàm: sinh vẽ từng thành phần của layout + gán dữ liệu cho layout
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        //4.1 Tao view
        ViewHolder holder = new ViewHolder();
        if(convertView==null)//nếu chưa tồn tại view thì cần tạo view mới
        {
            convertView = inflater.inflate(R.layout.custom_listview,null);//vẽ layout
            //ánh xạ từng thành phần
            holder.tvColor = convertView.findViewById(R.id.tvColor);
            holder.tvName= convertView.findViewById(R.id.tvName);
            holder.tvPhone = convertView.findViewById(R.id.tvPhone);
            //tạo template để lần sau sử dụng
            convertView.setTag(holder);
        }
        else //nếu đã tồn tại view -> lấy ra sử dụng
        {
            holder = (ViewHolder)convertView.getTag();
        }
        //4.2 Gan du lieu
        Contact contact = objects.get(position);
        holder.tvColor.setText(String.valueOf(position));
        holder.tvColor.setBackgroundColor(contact.getColor());
        holder.tvName.setText(contact.getName());
        holder.tvPhone.setText(contact.getPhone());
        return convertView;
    }

    //1. Tao lop anh xa voi ItemView
    public class ViewHolder {
        TextView tvColor, tvName, tvPhone;
    }
}
