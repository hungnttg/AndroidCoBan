package com.example.myapplication.bai3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.myapplication.R;

import java.util.ArrayList;
import java.util.List;

public class Bai33Main2Activity extends AppCompatActivity {
    ListView listView;
    List<String> ls;
    ArrayAdapter<String> adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bai33_main2);
        listView = findViewById(R.id.bai33lv);
        String[] list = new String[]{
                "Android co ban",
                "Android nang cao",
                "Lap trinh game co ban",
                "Lap trinh game nang cao"
        };
        adapter  =new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1,list);
        listView.setAdapter(adapter);

    }
}
