package com.example.myapplication.bai2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.myapplication.R;

public class Bai21Main2Activity extends AppCompatActivity {
    EditText txt1,txt2;
    Button btn1;
    TextView tv1;
    float tong = 0;
    float hieu,tich,thuong;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bai21_main2);
        txt1 = findViewById(R.id.b21Txt1);
        txt2 = findViewById(R.id.b21Txt2);
        btn1 = findViewById(R.id.b21Btn1);
        tv1 = findViewById(R.id.b21Tv1);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Lay du lieu nguoi dung nhap
                String a = txt1.getText().toString();
                String b = txt2.getText().toString();
                //Chuyen sang so thuc
                float so_a = Float.parseFloat(a);
                float so_b = Float.parseFloat(b);
                //tinh tong
//                tong = so_a+so_b;
//                hieu = so_a-so_b;
//                tich = so_a*so_b;
//                thuong =so_a/so_b;
                //đưa nội dung tính được lên textview
               // tv1.setText("Tong: "+String.valueOf(tong)
               // +"; Hieu: "+hieu+"; Tich: "+tich+"; Thuong: "+thuong);

                //Tạo 1 intent chứa dữ liệu
                Intent intent = new Intent(Bai21Main2Activity.this,Bai22Main2Activity.class);
                //đưa dữ liệu vào intent
                intent.putExtra("so_a",so_a);
                intent.putExtra("so_b",so_b);
                //chuyển dữ liệu sang activity 2
                startActivity(intent);

            }
        });

    }
}
