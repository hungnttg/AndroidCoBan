package com.example.myapplication.bai5;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.example.myapplication.R;

import java.util.ArrayList;
import java.util.List;

public class Bai61Main2Activity extends AppCompatActivity {
    EditText txt1,txt2,txt3;
    ListView listView;
    SanPhamDAO sanPhamDAO;
    ArrayAdapter<String> adapter;
    List<String> ds = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bai61_main2);
        txt1 = findViewById(R.id.b61Txt1);
        txt2 = findViewById(R.id.b61Txt2);
        txt3 = findViewById(R.id.b61Txt3);
        listView = findViewById(R.id.listview2);

        sanPhamDAO  = new SanPhamDAO(this);//tao moi lop dao
        ds.clear();//xoa trang danh sach
        ds = sanPhamDAO.getAllSanPhamString();//lay toan bo san pham dua vao danh sach
        adapter = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,ds);
        listView.setAdapter(adapter);//dua du lieu len listview

    }

    public void them(View view) {
        SanPham s = new SanPham();
        //đưa dữ liệu người dùng nhập vào sản phẩm
        s.setMasp(txt1.getText().toString());
        s.setTensp(txt2.getText().toString());
        s.setSoLuongSP(Integer.parseInt(txt3.getText().toString()));
        int kq = sanPhamDAO.insertSP(s);
        if(kq==-1)
        {
            Toast.makeText(getApplicationContext(),"Insert that bai",Toast.LENGTH_LONG).show();
        }
        if(kq==1)
        {
            Toast.makeText(getApplicationContext(),"Insert thanh cong",Toast.LENGTH_LONG).show();
        }
    }

    public void sua(View view) {
        SanPham s = new SanPham();
        //đưa dữ liệu người dùng nhập vào sản phẩm
        s.setMasp(txt1.getText().toString());
        s.setTensp(txt2.getText().toString());
        s.setSoLuongSP(Integer.parseInt(txt3.getText().toString()));
        int kq = sanPhamDAO.updateSP(s);
        if(kq==-1)
        {
            Toast.makeText(getApplicationContext(),"Update that bai",Toast.LENGTH_LONG).show();
        }
        if(kq==1)
        {
            Toast.makeText(getApplicationContext(),"Update thanh cong",Toast.LENGTH_LONG).show();
        }
    }

    public void hienthi(View view) {
        ds.clear();//xoa trang danh sach
        ds = sanPhamDAO.getAllSanPhamString();//lay toan bo san pham dua vao danh sach
        adapter = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,ds);
        listView.setAdapter(adapter);//dua du lieu len listview
    }

    public void xoa(View view) {
        String id = txt1.getText().toString().trim();
        int kq = sanPhamDAO.deleteSP(id);
        if(kq==-1)
        {
            Toast.makeText(getApplicationContext(),"Delete that bai",Toast.LENGTH_LONG).show();
        }
        if(kq==1)
        {
            Toast.makeText(getApplicationContext(),"Delete thanh cong",Toast.LENGTH_LONG).show();
        }

    }
}
