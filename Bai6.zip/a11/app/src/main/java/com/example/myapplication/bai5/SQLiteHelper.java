package com.example.myapplication.bai5;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class SQLiteHelper extends SQLiteOpenHelper {

    public static final String dbName = "QLBH";
    public static final int VERSION = 1;
    public static final String CREATE_TABLE_PROD="create TABLE product (id text PRIMARY KEY," +
            "name text,price real,image real);";
    public SQLiteHelper(Context context) {
        super(context, dbName, null, VERSION);//hàm tạo csdl
    }
    //các hàm tạo bảng
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(CREATE_TABLE_PROD);//tạo bảng product
        sqLiteDatabase.execSQL(SanPhamDAO.SQL_TAO_BANG_SANPHAM);//tạo bảng sanpham
    }
    //hàm nâng cấp bảng
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS product");
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS "+SanPhamDAO.TABLE_NAME);//xoa cu, tao moi
    }
}
