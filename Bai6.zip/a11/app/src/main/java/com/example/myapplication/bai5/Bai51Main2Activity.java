package com.example.myapplication.bai5;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.myapplication.R;

public class Bai51Main2Activity extends AppCompatActivity {
    //B1.Viết lớp model
    //B2. Viết lớp tạo CSDL và tạo bảng dữ liệu
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bai51_main2);
    }
}
