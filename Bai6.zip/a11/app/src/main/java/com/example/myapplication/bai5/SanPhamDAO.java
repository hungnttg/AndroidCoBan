package com.example.myapplication.bai5;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class SanPhamDAO {
    private SQLiteDatabase db;
    private SQLiteHelper dbHelper;
    private Context context;
    public static final String SQL_TAO_BANG_SANPHAM="CREATE TABLE sanpham (masp text PRIMARY KEY, " +
            "tensp text,soLuongSP text);";
    public static final String TABLE_NAME = "sanpham";
    //Tao database
    public SanPhamDAO(Context context)
    {
        this.context = context;
        dbHelper = new SQLiteHelper(context);//goi ham tao database
        db = dbHelper.getWritableDatabase();//cho phep ghi du lieu vao database
    }
    //viet ham insert
    public int insertSP(SanPham p)
    {
        ContentValues values = new ContentValues();
        values.put("masp",p.getMasp());
        values.put("tensp",p.getTensp());
        values.put("soLuongSP",String.valueOf(p.getSoLuongSP()));
        if(db.insert(TABLE_NAME,null,values)<=0)
        {
            return -1;//insert khong thanh cong
        }
        return 1;//insert thanh cong
    }
    //ham xoa du lieu
    public int deleteSP(String masp)
    {
        if(db.delete(TABLE_NAME,"masp=?",new String[]{masp})<=0)
        {
            return -1;//xoa khong thanh cong
        }
        return 1;//xoa thanh cong
    }
    //ham sua du lieu
    public int updateSP(SanPham p)
    {
        ContentValues values = new ContentValues();
        values.put("masp",p.getMasp());
        values.put("tensp",p.getTensp());
        values.put("soLuongSP",String.valueOf(p.getSoLuongSP()));
        if(db.update(TABLE_NAME,values,"masp=?",new String[]{p.getMasp()})<=0)
        {
            return -1;//update khong thanh cong
        }
        return 1;//update thanh cong
    }
    //ham lay toan bo du lieu
    public List<SanPham> getAllSanPham()
    {
        List<SanPham> ls = new ArrayList<>();//tạo 1 danh sách chứa các sp đọc được
        //tạo con trỏ đọc dữ lieeuu
        Cursor c = db.query(TABLE_NAME,null,null,null,
                null,null,null);
        c.moveToFirst();//di chuyen con tro ve ban ghi dau tien
        while (c.isAfterLast()==false)//trong khi khong phai ban ghi cuoi cung
        {
            SanPham s = new SanPham();//tao 1 doi tuong
            //them du lieu doc duoc vao doi tuong
            s.setMasp(c.getString(0));
            s.setTensp(c.getString(1));
            s.setSoLuongSP(c.getInt(2));
            //them doi tuong vao danh sach
            ls.add(s);
            //di chuyen con tro sang ban ghi tiep theo
            c.moveToNext();
        }
        c.close();//dong con tro
        return ls;
    }
    //ham lay toan bo du lieu
    public List<String> getAllSanPhamString()
    {
        List<String> ls = new ArrayList<>();//tạo 1 danh sách chứa các sp đọc được
        //tạo con trỏ đọc dữ lieeuu
        Cursor c = db.query(TABLE_NAME,null,null,null,
                null,null,null);
        c.moveToFirst();//di chuyen con tro ve ban ghi dau tien
        while (c.isAfterLast()==false)//trong khi khong phai ban ghi cuoi cung
        {
            SanPham s = new SanPham();//tao 1 doi tuong
            //them du lieu doc duoc vao doi tuong
            s.setMasp(c.getString(0));
            s.setTensp(c.getString(1));
            s.setSoLuongSP(c.getInt(2));
            //them doi tuong vao danh sach
            String str = s.getMasp()+" - "+s.getTensp()+" - "+s.getSoLuongSP();
            ls.add(str);
            //di chuyen con tro sang ban ghi tiep theo
            c.moveToNext();
        }
        c.close();//dong con tro
        return ls;
    }
}
