package com.example.myapplication.bai2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.myapplication.R;

public class Bai22Main2Activity extends AppCompatActivity {
    TextView tv2;
    float tong, hieu,tich,thuong;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bai22_main2);
        tv2 = findViewById(R.id.b22Tv1);
        //Lấy dữ liệu từ Ac1 chuyển sang
        Intent intent = getIntent();
        //đọc dữ liệu từ intent
        float so_a = intent.getFloatExtra("so_a",0);
        float so_b = intent.getFloatExtra("so_b",0);

        tong = so_a+so_b;
        hieu = so_a-so_b;
        tich = so_a*so_b;
        thuong = so_a/so_b;
       // tv2.setText("Tong: "+tong
       // +"; Hieu: "+hieu+"; Tich: "+tich+" ; Thuong: "+thuong);
    }

    public void ham_thuong(View view) {
        tv2.setText(String.valueOf(thuong));
    }

    public void ham_tich(View view) {
        tv2.setText(String.valueOf(tich));
    }

    public void ham_hieu(View view) {
        tv2.setText(String.valueOf(hieu));
    }

    public void ham_tong(View view) {
        tv2.setText(String.valueOf(tong));
    }
}
