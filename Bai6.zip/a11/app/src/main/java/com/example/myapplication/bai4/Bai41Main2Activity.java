package com.example.myapplication.bai4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.myapplication.R;

public class Bai41Main2Activity extends AppCompatActivity {
    EditText txt1, txt2;
    Button btn1;
    Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bai41_main2);
        txt1 = findViewById(R.id.b41Txt1);
        txt2 = findViewById(R.id.b41txt2);
        btn1 = findViewById(R.id.b41Btn1);
        intent = new Intent(Bai41Main2Activity.this,
                Bai41SecondActivity.class);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //1. Tao bundle
                Bundle bundle = new Bundle();
                //2. Lay du lieu nhap tu ban phim
                int a = Integer.parseInt(txt1.getText().toString());
                int b = Integer.parseInt(txt2.getText().toString());
                //3. Dua du lieu vao bundler
                bundle.putInt("so1",a);
                bundle.putInt("so2",b);
                //4. Dua bundle vao intent
                intent.putExtra("mybun",bundle);
                //5. Van chuyen du lieu sang activity khac
                startActivity(intent);
            }
        });
    }
}
