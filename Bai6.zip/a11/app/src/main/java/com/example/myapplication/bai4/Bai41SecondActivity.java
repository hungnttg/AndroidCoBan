package com.example.myapplication.bai4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import com.example.myapplication.R;

public class Bai41SecondActivity extends AppCompatActivity {
    TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bai41_second);
        textView = findViewById(R.id.b41SecondTv1);
        //1. Lay du lieu chuyen den
        Intent intent = getIntent();
        //2. Lay bundle
        Bundle bundle = intent.getBundleExtra("mybun");
        //3. lay du lieu tu bundle
        int a = bundle.getInt("so1");
        int b = bundle.getInt("so2");
        int us = uscln(a,b);
        int bs = bscnn(a,b);
        textView.setText("USCLN: "+us+" va BSCNN: "+bs);
    }
    int uscln(int a, int b)
    {
        if(b==0) return  a;
        return  uscln(b,a%b);
    }
    int bscnn(int a, int b)
    {
        return (a*b)/uscln(a,b);
    }
}
