package com.example.myapplication.bai2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.myapplication.R;

public class Bai22Main2Activity extends AppCompatActivity {
    TextView tvKQ;
    float kqCong,kqTru,kqNhan,kqChia;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bai22_main2);
        tvKQ = findViewById(R.id.bai22Tv1);
        Intent intent = getIntent();//Lấy dữ liệu chuyển từ activity 1 sang
        //lấy từng thành phần dữ liệu trong intent
        String a = intent.getStringExtra("so_a");
        float so_a = Float.parseFloat(a);
        String b = intent.getStringExtra("so_b");
        float so_b = Float.parseFloat(b);
        kqCong = so_a+so_b;
        kqTru = so_a-so_b;
        kqNhan = so_a*so_b;
        kqChia = so_a/so_b;

    }

    public void ham_chia(View view) {
        tvKQ.setText(String.valueOf(kqChia));
    }

    public void ham_nhan(View view) {
        tvKQ.setText(String.valueOf(kqNhan));
    }

    public void ham_tru(View view) {
        tvKQ.setText(String.valueOf(kqTru));
    }

    public void ham_cong(View view) {
        tvKQ.setText(String.valueOf(kqCong));
    }
}
