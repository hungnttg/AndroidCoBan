package com.example.myapplication.bai2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.myapplication.R;

public class Bai21Main2Activity extends AppCompatActivity {
    EditText txt1,txt2;
    Button btn1,btn2;
    TextView tv1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bai21_main2);
        txt1 = findViewById(R.id.b21Txt1);
        txt2 = findViewById(R.id.b21Txt2);
        btn1 = findViewById(R.id.b21Btn1);
        btn2 = findViewById(R.id.b21Btn2);
        tv1 = findViewById(R.id.b21Tv1);

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Đóng gói dữ liệu
                String a = txt1.getText().toString();//lấy dữ liệu người dùng nhập a
                String b  =txt2.getText().toString();//lấy dữ liệu người dùng nhập b
                //tạo intent để vận chuyển dữ liệu
                Intent intent = new Intent(Bai21Main2Activity.this, Bai22Main2Activity.class);
                //đưa dữ liệu vào intent
                intent.putExtra("so_a",a);
                intent.putExtra("so_b",b);
                //Chuyển qua intent sang activity khác
                startActivity(intent);
            }
        });

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String a = txt1.getText().toString();
                float so_a = Float.parseFloat(a);
                String b = txt2.getText().toString();
                float so_b = Float.parseFloat(b);
                float tong = so_a+so_b;
                tv1.setText(String.valueOf(tong));
            }
        });
    }
}
